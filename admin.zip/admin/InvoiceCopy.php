<?php
include('security.php');
include('CheckLogin.php');




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>

  
  
    <div class="container-0">
        <div class="conatiner-0-1" style="flex-direction: row; align-items: center; display: flex;">
            <div style="display: flex; flex-direction: column; text-align: left; color: #E74C3C;">
                <h1 style="letter-spacing: 6px; text-decoration: underline; font-size: 34px; ">DAR AL RABIE</h1>
                <h2>Mobile Phones Trading LLC</h2>
            </div>
            <div style=" margin: 0 6px; color: #E74C3C; height: 80px; width: 80px; background-color: #E74C3C; border-radius: 10px;">
                &nbsp;
            </div>
            <div style="color: #E74C3C; height: 80px; width: 60px; background-color: #E74C3C; border-radius: 10px;">
                &nbsp;
            </div>
            <div style=" margin: 0 6px; color: #E74C3C; height: 80px; width: 60px; background-color: #E74C3C; border-radius: 10px;">
                &nbsp;
            </div>
            <div style="margin: 0 6px; color: #E74C3C;">
                <h1>Awais Nazar</h1>
                <h3>+971 58 8086 338</h3>
                <h3>+971 56 4260 323</h3>
            </div>
            
        </div>
        <div class="conatiner-0-2" style="margin: 10px 0;">
            <h4 style="font-size: 16px; padding: 1rem; background-color: #E74C3C; color: white; border-radius: 6px; ">Deals in all Brand of Used Mobile Phones & Spare parts Software Repairing and Accessories</h3>
        </div>
        <div class="conatiner-0-3">
                <h4 style="font-size: 18px; text-align: center; color: #E74C3C;">Shop# 7-B, Salhe Building, JNP Signal, Industrial Area 6, Sharjah <br> United Arab Emirates  
                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
width="22" height="22"
viewBox="0 0 172 172"
style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#e74c3c"><path d="M160.53333,39.77213c-5.4868,2.43667 -11.38067,4.0764 -17.56693,4.816c6.31813,-3.784 11.1628,-9.77533 13.44467,-16.91907c-5.90533,3.50307 -12.4528,6.04867 -19.42453,7.42467c-5.57853,-5.94547 -13.52493,-9.66067 -22.31987,-9.66067c-16.8904,0 -30.5816,13.69693 -30.5816,30.5816c0,2.39653 0.2752,4.73573 0.7912,6.966c-25.41587,-1.2728 -47.94787,-13.4504 -63.038,-31.9576c-2.62587,4.51787 -4.13373,9.7696 -4.13373,15.38253c0,10.60667 5.39507,19.9692 13.59947,25.45027c-5.01093,-0.16053 -9.72947,-1.53653 -13.85173,-3.82413c0,0.13187 0,0.25227 0,0.38413c0,14.82067 10.53787,27.18173 24.53293,29.98533c-2.5628,0.69947 -5.26893,1.07213 -8.06107,1.07213c-1.96653,0 -3.8872,-0.19493 -5.75053,-0.54467c3.89293,12.14893 15.1876,20.99547 28.5692,21.242c-10.46333,8.2044 -23.65,13.09493 -37.98333,13.09493c-2.46533,0 -4.902,-0.14333 -7.29853,-0.43c13.5364,8.67453 29.60693,13.73707 46.88147,13.73707c56.25547,0 87.00907,-46.60053 87.00907,-87.0148c0,-1.3244 -0.02867,-2.64307 -0.086,-3.956c5.97987,-4.3172 11.16853,-9.7008 15.26787,-15.82973z"></path></g></g></svg> 
<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
width="22" height="22"
viewBox="0 0 172 172"
style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#e74c3c"><path d="M121.83333,21.5h-71.66667c-15.83117,0 -28.66667,12.8355 -28.66667,28.66667v71.66667c0,15.83117 12.8355,28.66667 28.66667,28.66667h40.28383v-49.88717h-16.7915v-19.52917h16.7915v-14.36917c0,-16.65533 10.18383,-25.7355 25.0475,-25.7355c5.0095,-0.01433 10.01183,0.24367 14.99267,0.7525v17.415h-10.234c-8.09833,0 -9.675,3.827 -9.675,9.47433v12.43417h19.35l-2.5155,19.52917h-16.94917v49.91583h11.36633c15.83117,0 28.66667,-12.8355 28.66667,-28.66667v-71.66667c0,-15.83117 -12.8355,-28.66667 -28.66667,-28.66667z"></path></g></g></svg>
                         dar.alrabi0077@gmail.com </h4>
                          <!-- <h4 style="text-align: center; color: #E74C3C ;  " >Dar Alrabie used computer Trading L.L.C</h4> -->
                         <h4 style="text-align: center; color: #E74C3C ;  " >TRN 100510881400003</h4>
        </div>
        <div class="conatiner-0-4">
            
        </div>
    </div>
<?php
if(isset($_POST['Customer_Invoice_copy_btn']))
{

   $Customer_id = $_POST['Customer_id'];
   $Name = $_POST['Name'];
   $Mobile_No = $_POST['Mobile_No'];
   $Selling_Date = $_POST['Selling'];
   $Phone = strval($Mobile_No);


   $y = 1000;

 ?>

    <div class="container-1" style="color: #E74C3C;">
        <!-- <h4 style="text-align: center; color: #E74C3C  ; font-size: 14px;  " >Dar Alrabie used computer Trading L.L.C</h4>
        <h4 style="text-align: center; color: #E74C3C  ; font-size: 14px;  " >TRN.. 100510881400003</h4> -->
        <div class="container-1-div1">
            <p>No. <span style="font-size: 42px;"><?php echo $Customer_id+$y ; ?></span> </p>
            <h2 style="margin-left: 30px; text-align: center;">فاتورۃ <br> INVOICE</h2>
            <div style="display: flex; flex-direction: row; align-items: center;">
                <p style="margin: 0 4px;">Date : </p>
               <p><?php echo $Selling_Date ; ?>   </p>
                <p style="margin: 0 4px; "> تاریخ</p>
            </div>
           
        </div><br>
         <p style="position: relative; left: 300px"><?php echo $Name.'-'.$Phone?></p>
        <div class="container-1-div2">
            <p style="">Mr./Mrs</p>
            <p style=" left: 370px;" >______________________________________________________________________</p>
            <p style=" left: 1000px;">السید/السادۃ</p>
            </div><br>
    </div>
    <table class="invoice_table">
        <tr style="border-style: inherit ;">
          <th> الرقم <br> S.No.</th>
          <th style="width: 400px;" class="description">التکاصیل <br> Description</th>
          <th> الکمیۃ <br> Qty.</th>
          <th>الکمیۃ <br> Rate</th>
          <th>Amount المبلغ <br> Dhs. درھم</th>
        </tr>
        <?php  

        $x = 1;
        $res = 0;
        $vat = 0;
        $query = "SELECT * FROM product" ;
        $query_run = mysqli_query($connection, $query);
        if(mysqli_num_rows($query_run) > 0){
          while($row = mysqli_fetch_assoc($query_run)){
            if($row['Invoice_ID'] === $Customer_id){
?>
        <tr style="border-style: inherit;">
          <td><?php echo $x ; ?></td>
          <?php 
if($row['Product_Category'] === 'Mobile' OR $row['Product_Category'] === 'Ipads' ){ 
  $id = $row['Product1_ID'];
    $query19 = "SELECT * FROM product1 WHERE Product1_ID='$id'";
    $query_run19 = mysqli_query($connection, $query19);
    $row19 = mysqli_fetch_assoc($query_run19);

   if($row19['IMEI2'] == 0){

 ?>     

   <td><?php echo $row['Product'] .'<br>'.$row19['Specification'].'<br>IMEI1:'.$row19['IMEI1']; ?></td>
 
 <?php
 }else{
    ?>
   <td><?php echo $row['Product'] .'<br>'.$row19['Specification'].'<br>IMEI1:'.$row19['IMEI1'].'<br>IMEI2:'.$row19['IMEI2']; ?></td>
    <?php
 }
      }
if($row['Product_Category'] != 'Mobile' AND $row['Product_Category'] != 'Ipads' ){ 

    ?>
          <td><?php echo $row['Product']; ?></td>
          <td><?php echo $row['Quantity']; ?></td>
      <?php }else{ ?>

          <td></td>
   <?php   } ?>
          <td><?php echo $row['Selling_Price_WT']; ?></td>
          <td><?php echo $row['Selling_Price_WT'] * $row['Quantity']; ?></td>
        </tr>
        <?php 
         if($row['Selling_Price'] > $row['Selling_Price_WT']){
        $v = $row['Selling_Price'] - $row['Selling_Price_WT'];
        $v = $v * $row['Quantity'];
        $vat = $vat + $v ;
    }
        $x +=1;
        $Price = $row['Quantity'] * $row['Selling_Price'] ;
        $res += $Price ;
          }} }
          ?>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td></td>
            <td>VAT</td>
            <td></td>
            <td>5%</td>
            <td><?php echo $vat; ?></td>
          </tr>
          
          <tr>
           <th  colspan="3" >Warranty _________________ Days only for used Item</th>
           <th>SubTotal</th>
           <th><?php echo $res; ?></th>
          </tr>
          <tr>
              <th colspan="6">Used and repaired Mobiles do not have LCD warranty, used items will not be returned or refunded. <div class="print" >  </div> </th>
          </tr>
      </table>
      <br>
      <div style="display: flex; flex-direction: row;">
      <button id="printPageButton" style="padding: 10px 20px;" onclick="window.print()">Print</button>
    <a href="Customer.php" >  <button  id="backbtn" style="padding: 10px 20px; margin-left: 10px; ">Back</button> </a>

      </div>
      
    <?php 

}
   
          
        ?>
</body>
</html>

<!--       
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 5v-4h-16v4h-4v14h2.764l2.001-4h14.472l2 4h2.763v-14h-4zm-14-2h12v2h-12v-2zm16 13.055l-1.527-3.055h-16.944l-1.529 3.056v-9.056h20v9.055zm-4 .945l3 6h-18l3-6h2.203l-1.968 4h11.528l-1.956-4h2.193zm3-8.5c0 .276-.224.5-.5.5s-.5-.224-.5-.5.224-.5.5-.5.5.224.5.5z"/></svg> -->