<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 




if(isset($_POST['Search_btn']))
{


    if($_POST['search'] != 'cutomer' )
    {

        ?>
        <div class="container-fluid">

          <!-- Datatables Example -->
          <div class="card shadow mb-4">

            <div class="card-body">

              <div class="table-responsive">

                 <?php

                 $Search_Item = $_POST['Search_Item'];
                 $search = $_POST['search'];

                 if($search != 'Mobile' AND $search != 'Ipads' AND $search != 'cutomer'){

                  $Category = $search ;

                  $search = 'category' ;

              }
              if($search === 'Mobile' OR $search === 'Ipads'){

                  $Category = $search ;

                  $search = 'static_category' ;

              }

              $query = "SELECT * FROM product1";
              $query_run = mysqli_query($connection, $query);
              ?>
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                   <tr>
                      <!--  <th> ID </th> -->
                       <th>Name </th>
                    <?php if($search === 'static_category'){ ?>
                        <th>Company </th>
                     <?php } ?>
                         <th>Specification </th>
                    <?php if($search === 'static_category'){ ?>
                        <th>IMEI1 </th>
                        <th>IMEI2 </th>
                    <?php } ?>
                   
                    <th>Buying Price </th>
                    <th>Selling Price </th>
                    <th>Purchased from </th>
                    <th>Purchased Date </th>
                    <?php if($search != 'static_category'){ ?>
                    <th>Quantity</th>
                     <?php } ?>
                     <th>SELL</th>
                <th>EDIT</th>
                <th>DELETE</th>
                </tr>
            </thead>
            <tbody>
               <?php
               if(mysqli_num_rows($query_run) > 0)        
               {
                  while($row = mysqli_fetch_assoc($query_run)){
  					// echo $Search_Item;
       //              echo $row['Name'];
                    $Name = $row['Name'];
                    $IMEI1 = $row['IMEI1'];
                    $Purchased_Date = $row['Purchased_Date'];
                    if(strcasecmp($Search_Item ,$Name) == 0 OR $Search_Item === $IMEI1 OR $Search_Item === $Purchased_Date){


                     ?>
                   
                <?php
            } 
        }
    }
    else {
      echo "No Record Found";
  }


  $Search_Item = "%".$Search_Item."%";
  $query10 = "SELECT * FROM product1 WHERE Name LIKE '".$Search_Item."' ";
  $query_run10 = mysqli_query($connection, $query10);
  if(mysqli_num_rows($query_run10) > 0){
    while($row10 = mysqli_fetch_assoc($query_run10)){
        if($row10['Category'] === $Category AND $row10['Status'] === 'AVAILABLE'){
            $x=$row10['Product1_ID'];
            $GLOBALS[$x]=$x;
           
            ?>
            <tr>
            <!--   <td><?php  //echo $row10['Product1_ID']; ?></td> -->

              <td><?php  echo $row10['Name']; ?></td>
              <?php if($search === 'static_category'){ ?>
                <td><?php  echo $row10['Company']; ?></td>
                   <?php } ?>
          <td><?php  echo $row10['Specification']; ?></td>
          <?php if($search === 'static_category'){ ?>
                <td><?php  echo $row10['IMEI1']; ?></td>
                <td><?php  echo $row10['IMEI2']; ?></td>
            <?php } ?>
            
            <td><?php  echo $row10['Buying_Price']; ?></td>
            <td><?php  echo $row10['Selling_Price']; ?></td>
            <td><?php  echo $row10['Purchased_from']; ?></td>
            <td><?php  echo $row10['Purchased_Date']; ?></td>
            <?php if($search != 'static_category'){ ?>
            <td><?php  echo $row10['Quantity']; ?></td>
        <?php } ?>
         <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row10['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row10['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row10['Name']; ?>">
         <?php if($row10['Category'] === 'Mobile'  OR $row10['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row10['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row10['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row10['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row10['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row10['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row10['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row10['Purchased_Date']; ?>">
                                <?php 
if($row10['Category'] != 'Mobile' ){ 
    if($row10['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row10['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row10['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row10['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>



        </tr>
    <?php }} }

    $query11 = "SELECT * FROM product1 WHERE Specification LIKE '".$Search_Item."' ";
  $query_run11 = mysqli_query($connection, $query11);
  if(mysqli_num_rows($query_run11) > 0){
    while($row11 = mysqli_fetch_assoc($query_run11)){
        if($row11['Category'] === $Category AND $row11['Status'] === 'AVAILABLE'){
             $x=$row11['Product1_ID'];
                if(!isset($GLOBALS[$x]) ){
                      $GLOBALS[$x]=$x;
           
            ?>
            <tr>
            <!--   <td><?php  //echo $row11['Product1_ID']; ?></td> -->

              <td><?php  echo $row11['Name']; ?></td>
              <?php if($search === 'static_category'){ ?>
                <td><?php  echo $row11['Company']; ?></td>
                   <?php } ?>
          <td><?php  echo $row11['Specification']; ?></td>
          <?php if($search === 'static_category'){ ?>
                <td><?php  echo $row11['IMEI1']; ?></td>
                <td><?php  echo $row11['IMEI2']; ?></td>
            <?php } ?>
            
            <td><?php  echo $row11['Buying_Price']; ?></td>
            <td><?php  echo $row11['Selling_Price']; ?></td>
            <td><?php  echo $row11['Purchased_from']; ?></td>
            <td><?php  echo $row11['Purchased_Date']; ?></td>
            <?php if($search != 'static_category'){ ?>
            <td><?php  echo $row11['Quantity']; ?></td>
        <?php } ?>
         <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row11['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row11['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row11['Name']; ?>">
         <?php if($row11['Category'] === 'Mobile'  OR $row11['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row11['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row11['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row11['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row11['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row11['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row11['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row11['Purchased_Date']; ?>">
                                <?php 
if($row11['Category'] != 'Mobile' ){ 
    if($row11['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row11['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row11['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row11['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>



        </tr>
    <?php }} } }


    if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
      $query13 = "SELECT * FROM product1 WHERE Company LIKE '".$Search_Item."' ";
      $query_run13  = mysqli_query($connection, $query13 );
      if(mysqli_num_rows($query_run13 ) > 0){
        while($row13  = mysqli_fetch_assoc($query_run13 )){
            if($row13['Category'] === $Category AND $row13['Status'] === 'AVAILABLE'){
                 $x = $row13['Product1_ID'];
                if(!isset($GLOBALS[$x]) ){
                      $GLOBALS[$x]=$x;

                ?>
                <tr>
               <!--    <td><?php  //echo $row13['Product1_ID']; ?></td> -->

                  <td><?php  echo $row13['Name']; ?></td>

                  <td><?php  echo $row13['Company']; ?></td>
               <td><?php  echo $row13['Specification']; ?></td>
                  <td><?php  echo $row13['IMEI1']; ?></td>
                  <td><?php  echo $row13['IMEI2']; ?></td>

                  
                  <td><?php  echo $row13['Buying_Price']; ?></td>
                  <td><?php  echo $row13['Selling_Price']; ?></td>
                  <td><?php  echo $row13['Purchased_from']; ?></td>
                  <td><?php  echo $row13['Purchased_Date']; ?></td>
                   <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row13['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row13['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row13['Name']; ?>">
         <?php if($row13['Category'] === 'Mobile'  OR $row13['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row13['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row13['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row13['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row13['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row13['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row13['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row13['Purchased_Date']; ?>">
                                <?php 
if($row13['Category'] != 'Mobile' ){ 
    if($row13['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row13['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row13['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row13['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





              </tr>
          <?php 
           }} } }
      }
      if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
          $query16 = "SELECT * FROM product1 WHERE IMEI1 LIKE '".$Search_Item."' ";
          $query_run16 = mysqli_query($connection, $query16 );
          if(mysqli_num_rows($query_run16 ) > 0){
            while($row16  = mysqli_fetch_assoc($query_run16)){
                if($row16['Category'] === $Category AND $row16['Status'] === 'AVAILABLE'){
                    $y=$row16['Product1_ID'];
                     if(!isset($GLOBALS[$y]) ){
                      $GLOBALS[$y]=$y;
                    ?>
                    <tr>
                  <!--     <td><?php  //echo $row16['Product1_ID']; ?></td> -->

                      <td><?php  echo $row16['Name']; ?></td>

                      <td><?php  echo $row16['Company']; ?></td>
                      <td><?php  echo $row16['Specification']; ?></td>
                      <td><?php  echo $row16['IMEI1']; ?></td>
                      <td><?php  echo $row16['IMEI2']; ?></td>

                     
                      <td><?php  echo $row16['Buying_Price']; ?></td>
                      <td><?php  echo $row16['Selling_Price']; ?></td>
                      <td><?php  echo $row16['Purchased_from']; ?></td>
                      <td><?php  echo $row16['Purchased_Date']; ?></td>
                    <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row16['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row16['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row16['Name']; ?>">
         <?php if($row16['Category'] === 'Mobile'  OR $row16['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row16['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row16['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row16['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row16['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row16['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row16['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row16['Purchased_Date']; ?>">
                                <?php 
if($row16['Category'] != 'Mobile' ){ 
    if($row16['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row16['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row16['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row16['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                  </tr>
              <?php }}   } }
          }

           if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
          $query17 = "SELECT * FROM product1 WHERE IMEI2 LIKE '".$Search_Item."' ";
          $query_run17 = mysqli_query($connection, $query17 );
          if(mysqli_num_rows($query_run17 ) > 0){
            while($row17  = mysqli_fetch_assoc($query_run17)){
                if($row17['Category'] === $Category AND $row17['Status'] === 'AVAILABLE'){
                    $y=$row17['Product1_ID'];
                     if(!isset($GLOBALS[$y]) ){
                      $GLOBALS[$y]=$y;
                    ?>
                    <tr>
                  <!--     <td><?php  //echo $row17['Product1_ID']; ?></td> -->

                      <td><?php  echo $row17['Name']; ?></td>

                      <td><?php  echo $row17['Company']; ?></td>
                      <td><?php  echo $row17['Specification']; ?></td>
                      <td><?php  echo $row17['IMEI1']; ?></td>
                      <td><?php  echo $row17['IMEI2']; ?></td>

                     
                      <td><?php  echo $row17['Buying_Price']; ?></td>
                      <td><?php  echo $row17['Selling_Price']; ?></td>
                      <td><?php  echo $row17['Purchased_from']; ?></td>
                      <td><?php  echo $row17['Purchased_Date']; ?></td>
                    <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row17['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row17['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row17['Name']; ?>">
         <?php if($row17['Category'] === 'Mobile'  OR $row17['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row17['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row17['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row17['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row17['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row17['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row17['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row17['Purchased_Date']; ?>">
                                <?php 
if($row16['Category'] != 'Mobile' ){ 
    if($row16['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row17['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row17['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row17['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                  </tr>
              <?php }}   } }
          }


                //$Search_Item = "%".$Search_Item."%";
              $query19 = "SELECT * FROM product1 WHERE Purchased_Date LIKE '".$Search_Item."' ";
              $query_run19 = mysqli_query($connection, $query19);
              if(mysqli_num_rows($query_run19) > 0){
                while($row19 = mysqli_fetch_assoc($query_run19)){
                    if($row19['Category'] === $Category AND $row19['Status'] === 'AVAILABLE'){
                        $z = $row19['Product1_ID'];
                          if(!isset($GLOBALS[$z]) ){
                            $GLOBALS[$z] = $z
                        ?>
                        <tr>
                          <!-- <td><?php  //echo $row19['Product1_ID']; ?></td> -->

                          <td><?php  echo $row19['Name']; ?></td>
               <?php if($search === 'static_category'){ ?>
                            <td><?php  echo $row19['Company']; ?></td>
                               <?php } ?>
                               <td><?php  echo $row19['Specification']; ?></td>
                <?php if($search === 'static_category'){ ?>
                            <td><?php  echo $row19['IMEI1']; ?></td>
                            <td><?php  echo $row19['IMEI2']; ?></td>
                        <?php } ?>
                        
                        <td><?php  echo $row19['Buying_Price']; ?></td>
                        <td><?php  echo $row19['Selling_Price']; ?></td>
                        <td><?php  echo $row19['Purchased_from']; ?></td>
                        <td><?php  echo $row19['Purchased_Date']; ?></td>
                        <?php if($search != 'static_category'){ ?>
                        <td><?php  echo $row19['Quantity']; ?></td>
                    <?php } ?>
                     <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row19['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row19['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row19['Name']; ?>">
         <?php if($row19['Category'] === 'Mobile'  OR $row19['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row19['Company']; ?>">
                               
                                <input type="hidden" name="edit_imei1" value="<?php echo $row19['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row19['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row19['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row19['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row19['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row19['Purchased_Date']; ?>">
                                <?php 
if($row19['Category'] != 'Mobile' ){ 
    if($row19['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row19['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row19['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row19['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                    </tr>


                <?php }} }       }    

  //$Search_Item = "%".$Search_Item."%";
              $query20 = "SELECT * FROM product1 WHERE Purchased_from LIKE '".$Search_Item."' ";
              $query_run20= mysqli_query($connection, $query20);
              if(mysqli_num_rows($query_run20) > 0){
                while($row20 = mysqli_fetch_assoc($query_run20)){
                    if($row20['Category'] === $Category AND $row20['Status'] === 'AVAILABLE'){
                        $z = $row20['Product1_ID'];
                          if(!isset($GLOBALS[$z]) ){
                            $GLOBALS[$z] = $z
                        ?>
                        <tr>
                          <!-- <td><?php  //echo $row20['Product1_ID']; ?></td> -->

                          <td><?php  echo $row20['Name']; ?></td>
               <?php if($search === 'static_category'){ ?>
                            <td><?php  echo $row20['Company']; ?></td>
                               <?php } ?>
                               <td><?php  echo $row20['Specification']; ?></td>
                <?php if($search === 'static_category'){ ?>
                            <td><?php  echo $row20['IMEI1']; ?></td>
                            <td><?php  echo $row20['IMEI2']; ?></td>
                        <?php } ?>
                        
                        <td><?php  echo $row20['Buying_Price']; ?></td>
                        <td><?php  echo $row20['Selling_Price']; ?></td>
                        <td><?php  echo $row20['Purchased_from']; ?></td>
                        <td><?php  echo $row20['Purchased_Date']; ?></td>
                        <?php if($search != 'static_category'){ ?>
                        <td><?php  echo $row20['Quantity']; ?></td>
                    <?php } ?>
                     <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row20['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row20['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row20['Name']; ?>">
         <?php if($row20['Category'] === 'Mobile'  OR $row20['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row20['Company']; ?>">
                               
                                <input type="hidden" name="edit_imei1" value="<?php echo $row20['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row20['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row20['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row20['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row20['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row20['Purchased_Date']; ?>">
                                <?php 
if($row20['Category'] != 'Mobile' ){ 
    if($row20['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row20['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row20['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row20['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                    </tr>


                <?php }} }       }    


                ?>
            </tbody>
        </table>

    </div>
</div>
</div>
</div>

<?php 
}
elseif ($_POST['search'] === 'cutomer') { ?>
    <div class="container-fluid">

        <!-- Datatables Example -->
        <div class="card shadow mb-4">

            <div class="card-body">

              <div class="table-responsive">

                <?php

                $Search_Item = $_POST['Search_Item'];
                $Search_Invoice = $Search_Item;
                $search = $_POST['search'];

                if($Search_Item != NULL){

                $query = "SELECT * FROM customer";
                $query_run = mysqli_query($connection, $query);
                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Invoice ID</th>
                            <th>Name </th>
                            <th>Mobile No </th>
                            <th>Selling Date</th>
                            <th>Invoice</th>
                            <th>Delete</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // if(mysqli_num_rows($query_run) > 0)        
                        // {
                        //     while($row = mysqli_fetch_assoc($query_run)){
                        //         if(strcasecmp($Search_Item ,$row['Name']) == 0 OR $Search_Item === $row['Selling_Date'] OR $Search_Item === $row['Mobile_No']){
                                    ?>
                                   <!--  <tr>

                                        <td><?php // echo $row['Name']; ?></td>
                                        <td><?php // echo $row['Mobile_No']; ?></td>
                                        <td><?php // echo $row['Address']; ?></td>
                                        <td><?php // echo $row['Customer_ID']; ?></td>
                                        <td><?php // echo $row['Selling_Date']; ?></td>
                                        <td style="padding: 0; margin: 0;">
                                            <form action="InvoiceCopy.php" method="post">
                                                <input type="hidden" name="Customer_id" value="<?php //echo $row['Customer_ID']; ?>">
                                                <input type="hidden" name="Selling" value="<?php //echo $row['Selling_Date']; ?>">
                                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
                                            </form>
                                        </td>




                                    </tr> -->
                                    <?php
                            //     }
                            // } }

                            $Search_Item = "%".$Search_Item."%";
                            $query2 = "SELECT * FROM customer WHERE Name LIKE '".$Search_Item."' ";
                            $query_run2 = mysqli_query($connection, $query2);
                            if(mysqli_num_rows($query_run2) > 0){
                                while($row2 = mysqli_fetch_assoc($query_run2)){
                                    $x=$row2['Customer_ID'];
                                     $GLOBALS[$x]=$x;


                                    ?>
                                    <tr>
                                        <td><?php  echo $row2['Customer_ID'] + 1000; ?></td>
                                        <td><?php  echo $row2['Name']; ?></td>
                                        <td><?php  echo $row2['Mobile_No']; ?></td>                            
                                        <td><?php  echo $row2['Selling_Date']; ?></td>
                                        <td style="padding: 0; margin: 0;">
                                            <form action="InvoiceCopy.php" method="post">
                                                <input type="hidden" name="Customer_id" value="<?php echo $row2['Customer_ID']; ?>">
                                                <input type="hidden" name="Selling" value="<?php echo $row2['Selling_Date']; ?>">
                                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
                                            </form>
                                        </td>
                                        <td style="padding: 0; margin: 0;">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="Customer_id" value="<?php echo $row2['Customer_ID']; ?>">
                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this INVOICE  ?')" name="delete_invoice_btn" class="btn btn-danger"> Delete Invoice </button>
                            </form>
                        </td>




                                    </tr>
                                    <?php
                                }}


                                                

                                                $query7 = "SELECT * FROM customer WHERE Mobile_No LIKE '".$Search_Item."' ";
                                                $query_run7 = mysqli_query($connection, $query7);
                                                if(mysqli_num_rows($query_run7) > 0){
                                                    while($row7 = mysqli_fetch_assoc($query_run7)){
                                                         $x = $row7['Customer_ID'];
                                                           if(!isset($GLOBALS[$x]) ){
                                                             $GLOBALS[$x]=$x;
                                                        ?>
                                                        <tr>
                                                            <td><?php  echo $row7['Customer_ID'] + 1000; ?></td>
                                                            <td><?php  echo $row7['Name']; ?></td>
                                                            <td><?php  echo $row7['Mobile_No']; ?></td>
                                                            <td><?php  echo $row7['Selling_Date']; ?></td>
                                                            <td style="padding: 0; margin: 0;">
                                                                <form action="InvoiceCopy.php" method="post">
                                                                    <input type="hidden" name="Customer_id" value="<?php echo $row7['Customer_ID']; ?>">
                                                                    <input type="hidden" name="Selling" value="<?php echo $row7['Selling_Date']; ?>">
                                                                    <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
                                                                </form>
                                                            </td>
                                                            <td style="padding: 0; margin: 0;">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="Customer_id" value="<?php echo $row7['Customer_ID']; ?>">
                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this INVOICE  ?')" name="delete_invoice_btn" class="btn btn-danger"> Delete Invoice </button>
                            </form>
                        </td>




                                                        </tr>
                                                        <?php
                                                    }}}

                                                   
                                                        

                                                            $query7 = "SELECT * FROM customer WHERE Selling_Date LIKE '".$Search_Item."' ";
                                                            $query_run7 = mysqli_query($connection, $query7);
                                                            if(mysqli_num_rows($query_run7) > 0){
                                                                while($row7 = mysqli_fetch_assoc($query_run7)){
                                                                    $x = $row7['Customer_ID'];
                                                           if(!isset($GLOBALS[$x]) ){
                                                             $GLOBALS[$x]=$x;
                                                                    ?>
                                                                    <tr>
                                                                        <td><?php  echo $row7['Customer_ID'] + 1000; ?></td>
                                                                        <td><?php  echo $row7['Name']; ?></td>
                                                                        <td><?php  echo $row7['Mobile_No']; ?></td>
                                                                        <td><?php  echo $row7['Selling_Date']; ?></td>
                                                                        <td style="padding: 0; margin: 0;">
                                                                            <form action="InvoiceCopy.php" method="post">
                                                                                <input type="hidden" name="Customer_id" value="<?php echo $row7['Customer_ID']; ?>">
                                                                                <input type="hidden" name="Selling" value="<?php echo $row7['Selling_Date']; ?>">
                                                                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
                                                                            </form>
                                                                        </td>
                                                                        <td style="padding: 0; margin: 0;">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="Customer_id" value="<?php echo $row7['Customer_ID']; ?>">
                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this INVOICE  ?')" name="delete_invoice_btn" class="btn btn-danger"> Delete Invoice </button>
                            </form>
                        </td>




                                                                    </tr>
                                                                    <?php
                                                                }} }

                                                                   if(is_numeric($Search_Invoice)){
                                                                 $id = (int)$Search_Invoice - 1000;
                                                            $query18 = "SELECT * FROM customer WHERE Customer_ID= '$id' ";
                                                            $query_run18 = mysqli_query($connection, $query18);
                                                          
                                                            $row18 = mysqli_fetch_assoc($query_run18);
                                                                    
                                                                    ?>
                                                                    <tr>
                                                                        <td><?php  echo $row18['Customer_ID'] + 1000; ?></td>
                                                                        <td><?php  echo $row18['Name']; ?></td>
                                                                        <td><?php  echo $row18['Mobile_No']; ?></td>        
                                                                        <td><?php  echo $row18['Selling_Date']; ?></td>
                                                                        <td style="padding: 0; margin: 0;">
                                                                            <form action="InvoiceCopy.php" method="post">
                                                                                <input type="hidden" name="Customer_id" value="<?php echo $row18['Customer_ID']; ?>">
                                                                                <input type="hidden" name="Selling" value="<?php echo $row18['Selling_Date']; ?>">
                                                                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
                                                                            </form>
                                                                        </td>
                                                                        <td style="padding: 0; margin: 0;">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="Customer_id" value="<?php echo $row18['Customer_ID']; ?>">
                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this INVOICE  ?')" name="delete_invoice_btn" class="btn btn-danger"> Delete Invoice </button>
                            </form>
                        </td>




                                                                    </tr>
                                                                    <?php
                                                                     }


                                                                 
                                                            } 

                                                                ?>
                                                            </tbody>
                                                        </table>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php

                                    }

                                }



                                include('includes/scripts.php'); 
                                include('includes/footer.php'); 
                            ?>