<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>





	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Add Customer</h6>

		</div>
		<div class="card-body">


			<form action="Invoice.php" method="POST" >

				<div class="form-group">
					<label>Name</label>
					<input type="text" name="Name"  value="" class="form-control" placeholder="Enter Customer Name">
					

		<br></div>		
		<div class="form-group">
					<label>Mobile No</label>
					<input type="number" name="Mobile_No"  value="" class="form-control" placeholder="Enter Customer Mobile No">
					

		<br></div>	
		

		<div class="form-group">
					<label>Selling Date</label>
					<input type="Date" name="Selling_Date"  value="<?= date("Y-m-d"); ?>" class="form-control" placeholder="">
					

		<br></div>	
		
<center  style="display: flex; flex-direction: row; align-items: center; justify-content: center; " class="cntr_btns">

				<a  style="margin-bottom: 10px  ;" href="PreCheckout.php" class="btn btn-danger"> CANCEL </a>
				<div style="margin:0 1rem; ">&nbsp;</div>
				<button type="submit" name="add_customer_btn" class="btn btn-primary"> Generate Invoice </button>
</center>
			</form>

			

		<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>