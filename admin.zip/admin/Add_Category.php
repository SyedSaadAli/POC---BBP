<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width" />
    <title>HTML Result</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" 
          integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

         <script type="text/javascript">onclick="return confirm('Are you sure you want to delete the catagory?')"</script>
</head>
<body>
<script type="text/javascript">
// 	if (confirm('Are you sure you want to save this thing into the database?')) {
//   // Save it!
//   console.log('Thing was saved to the database.');
// } else {
//   // Do nothing!
//   console.log('Thing was not saved to the database.');
// }
</script>
</body>
</html>
<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" 
          integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">




<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="Add.php" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>
					<button  type="submit" name="add_category" class="btn btn-primary">
						ADD Product Category
					</button>
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"> Product Categorys


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:green; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:green;" text-align:center;> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM product_category";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				<!-- <th> ID </th> -->
  				<th>Category </th>
  				<th>ADD PRODUCT</th>
  				<th>EDIT PRODUCT</th>
  				<th>DELETE</th>
  			</tr>
  		</thead>
  		<tbody>
  			<?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					?>
  					<tr>
  					<!-- 	<td><?php  //echo $row['Product_Category_ID']; ?></td> -->
  						<td><?php  echo $row['Category'];?></td>

  						<?php 

		if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){

			?>

  						<td style="padding: 0; margin: 0;">
  							<form action="Add_Products.php" method="post">
  								<input type="hidden" name="product_category_id" value="<?php echo $row['Product_Category_ID']; ?>">
  								<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="add_p1_btn" class="btn btn-primary add_product_btn"> ADD PRODUCT</button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="" method="">
  								
  								<button style="margin-left: 1rem; margin-top: 10px;" type="" name="" class="btn btn-primary add_product_btn" > FIXED</button>
  							</form>
  						</td>

  						<?php 

                          } 
                           else
                           {

  						?>

  						<td style="padding: 0; margin: 0;">
  							<form action="Add_Products.php" method="post">
  								<input type="hidden" name="product_category_id" value="<?php echo $row['Product_Category_ID']; ?>">
  									<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="add_p2_btn" class="btn btn-primary "> ADD PRODUCT</button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Category.php" method="post">
  								<input type="hidden" name="product_category_id" value="<?php echo $row['Product_Category_ID']; ?>">
  									<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="edit_p2_btn" class="btn btn-primary " onclick="javascript: return confirm('Are you sure you want to EDIT this product category ?')"> EDIT PRODUCT</button>
  							</form>
  						</td>

  						<?php 

  				     	}

                  if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){

                           
  						?>
              <td style="padding: 0; margin: 0;">
                <form action="#" method="#">
                 
                  <button style="margin-left: 1rem; margin-top: 10px; width: 75px;" type="" name="C_delete_btn" class="btn btn-primary" > FIXED   </button>
                </form>
              </td>

              <?php
            }else{
               ?>

  						<td style="padding: 0; margin: 0;">
  							<form action="code1.php" method="post">
  								<input type="hidden" name="C_delete_id" value="<?php echo $row['Product_Category_ID']; ?>">
  								<input type="hidden" name="Category" value="<?php echo $row['Category']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px; width: 75px;" type="submit" name="C_delete_btn" class="btn btn-danger" onclick="javascript: return confirm('Are you sure you want to DELETE this product category ?')" > DELETE</button>
  							</form>
  						</td>
           <?php } ?>

  					</tr>
  					<?php
  				} 
  			}
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->
  
  <!-- Logout Modal-->
<!--   <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">�</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button style="margin-bottom: 10px  ;" class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
<div style="margin:0 1rem; ">&nbsp;</div>
          <form action="logout.php" method="POST"> 
          
            <button type="submit" name="logout_btn" class="btn btn-primary">Logout</button>

          </form>


        </div>
      </div>
    </div>
  </div> -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>