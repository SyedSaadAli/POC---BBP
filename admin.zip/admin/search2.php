<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 

?>

<style> 
    .misearchform{
        padding: 20px 30px;
        width: 600px;
    }
    .mibtn{
        padding: 5px 20px;
        background-color:#054181;
        color: white;
    }
    .micat{
        padding: 5px 20px;
     
    }
    .mibtn:hover{
        transition: 0.3s;
        background-color: #053181;
    }
    .misearch{
        padding: 5px 20px;
        border:2px solid #054181;
    }
    .micat option{
        background-color: none !important;
        
    }
    </style>

<?php


if(isset($_POST['Search_btn']))
{


    

        ?>
        <div class="container-fluid">

          <!-- Datatables Example -->
          <div class="card shadow mb-4">
               <!--Search Bar Code Start-->
       
    
 <form action="search2.php" method="POST" class="misearchform">
        <input type="text" name="search" placeholder="Enter to Search" class="misearch">
        <input type="submit" name="Search_btn" value="Search" class="mibtn">
        <select name="cat" id="cat" class="micat">
            <option value="Mobile">Mobile</option>
            <option value="Ipads">ipad</option>
        </select>
    </form>



        <!--Search Bar Code Ends-->

            <div class="card-body">

              <div class="table-responsive">

                 <?php

                 $Category = $_POST['cat'];
                 $search = $_POST['search'];

               

              $query = "SELECT * FROM product1";
              $query_run = mysqli_query($connection, $query);
              ?>
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                   <tr>
                      <!--  <th> ID </th> -->
                       <th>Name </th>
                 
                        <th>Company </th>
             
                         <th>Specification </th>
               
                        <th>IMEI1 </th>
                        <th>IMEI2 </th>
  
                   
                    <th>Buying Price </th>
                    <th>Selling Price </th>
                    <th>Purchased from </th>
                    <th>Purchased Date </th>
                   
                    <!--  <th>SELL</th> -->
                <th>EDIT</th>
                <th>DELETE</th>
                </tr>
            </thead>
            <tbody>
              <?php

  $Search_Item = "%".$search."%";
  $query10 = "SELECT * FROM product1 WHERE Name LIKE '".$Search_Item."' ";
  $query_run10 = mysqli_query($connection, $query10);
  if(mysqli_num_rows($query_run10) > 0){
    while($row10 = mysqli_fetch_assoc($query_run10)){
        if($row10['Category'] === $Category AND $row10['Status'] === 'SOLD'){
            $x=$row10['Product1_ID'];
            $GLOBALS[$x]=$x;
           
            ?>
            <tr>
            <!--   <td><?php  //echo $row10['Product1_ID']; ?></td> -->

              <td><?php  echo $row10['Name']; ?></td>
             
                <td><?php  echo $row10['Company']; ?></td>
                  
          <td><?php  echo $row10['Specification']; ?></td>
        
                <td><?php  echo $row10['IMEI1']; ?></td>
                <td><?php  echo $row10['IMEI2']; ?></td>
          
            
            <td><?php  echo $row10['Buying_Price']; ?></td>
            <td><?php  echo $row10['Selling_Price']; ?></td>
            <td><?php  echo $row10['Purchased_from']; ?></td>
            <td><?php  echo $row10['Purchased_Date']; ?></td>
           
        <!--  <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row10['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row10['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row10['Name']; ?>">
         
                                <input type="hidden" name="edit_company" value="<?php echo $row10['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row10['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row10['IMEI2']; ?>">
                          
                                <input type="hidden" name="edit_specs" value="<?php echo $row10['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row10['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row10['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row10['Purchased_Date']; ?>">

                                <input type="hidden" name="edit_category" value="<?php echo $row10['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row10['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>



        </tr>
    <?php }} }

    $query11 = "SELECT * FROM product1 WHERE Specification LIKE '".$Search_Item."' ";
  $query_run11 = mysqli_query($connection, $query11);
  if(mysqli_num_rows($query_run11) > 0){
    while($row11 = mysqli_fetch_assoc($query_run11)){
        if($row11['Category'] === $Category AND $row11['Status'] === 'SOLD'){
             $x=$row11['Product1_ID'];
                if(!isset($GLOBALS[$x]) ){
                      $GLOBALS[$x]=$x;
           
            ?>
            <tr>
            <!--   <td><?php  //echo $row11['Product1_ID']; ?></td> -->

              <td><?php  echo $row11['Name']; ?></td>
              
                <td><?php  echo $row11['Company']; ?></td>
                
          <td><?php  echo $row11['Specification']; ?></td>
         
                <td><?php  echo $row11['IMEI1']; ?></td>
                <td><?php  echo $row11['IMEI2']; ?></td>
            
            
            <td><?php  echo $row11['Buying_Price']; ?></td>
            <td><?php  echo $row11['Selling_Price']; ?></td>
            <td><?php  echo $row11['Purchased_from']; ?></td>
            <td><?php  echo $row11['Purchased_Date']; ?></td>
          
        <!--  <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row11['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row11['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row11['Name']; ?>">
        
                                <input type="hidden" name="edit_company" value="<?php echo $row11['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row11['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row11['IMEI2']; ?>">
                               
                                <input type="hidden" name="edit_specs" value="<?php echo $row11['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row11['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row11['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row11['Purchased_Date']; ?>">
 
                                <input type="hidden" name="edit_category" value="<?php echo $row11['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row11['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>



        </tr>
    <?php }} } }


    // if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
      $query13 = "SELECT * FROM product1 WHERE Company LIKE '".$Search_Item."' ";
      $query_run13  = mysqli_query($connection, $query13 );
      if(mysqli_num_rows($query_run13 ) > 0){
        while($row13  = mysqli_fetch_assoc($query_run13 )){
            if($row13['Category'] === $Category AND $row13['Status'] === 'SOLD'){
                 $x = $row13['Product1_ID'];
                if(!isset($GLOBALS[$x]) ){
                      $GLOBALS[$x]=$x;

                ?>
                <tr>
               <!--    <td><?php  //echo $row13['Product1_ID']; ?></td> -->

                  <td><?php  echo $row13['Name']; ?></td>

                  <td><?php  echo $row13['Company']; ?></td>
               <td><?php  echo $row13['Specification']; ?></td>
                  <td><?php  echo $row13['IMEI1']; ?></td>
                  <td><?php  echo $row13['IMEI2']; ?></td>

                  
                  <td><?php  echo $row13['Buying_Price']; ?></td>
                  <td><?php  echo $row13['Selling_Price']; ?></td>
                  <td><?php  echo $row13['Purchased_from']; ?></td>
                  <td><?php  echo $row13['Purchased_Date']; ?></td>
                  <!--  <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row13['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row13['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row13['Name']; ?>">
     
                                <input type="hidden" name="edit_company" value="<?php echo $row13['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row13['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row13['IMEI2']; ?>">
                       
                                <input type="hidden" name="edit_specs" value="<?php echo $row13['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row13['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row13['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row13['Purchased_Date']; ?>">
 
                                <input type="hidden" name="edit_category" value="<?php echo $row13['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row13['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





              </tr>
          <?php 
           }} } }
      // }
      // if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
          $query16 = "SELECT * FROM product1 WHERE IMEI1 LIKE '".$Search_Item."' ";
          $query_run16 = mysqli_query($connection, $query16 );
          if(mysqli_num_rows($query_run16 ) > 0){
            while($row16  = mysqli_fetch_assoc($query_run16)){
                if($row16['Category'] === $Category AND $row16['Status'] === 'SOLD'){
                    $y=$row16['Product1_ID'];
                     if(!isset($GLOBALS[$y]) ){
                      $GLOBALS[$y]=$y;
                    ?>
                    <tr>
                  <!--     <td><?php  //echo $row16['Product1_ID']; ?></td> -->

                      <td><?php  echo $row16['Name']; ?></td>

                      <td><?php  echo $row16['Company']; ?></td>
                      <td><?php  echo $row16['Specification']; ?></td>
                      <td><?php  echo $row16['IMEI1']; ?></td>
                      <td><?php  echo $row16['IMEI2']; ?></td>

                     
                      <td><?php  echo $row16['Buying_Price']; ?></td>
                      <td><?php  echo $row16['Selling_Price']; ?></td>
                      <td><?php  echo $row16['Purchased_from']; ?></td>
                      <td><?php  echo $row16['Purchased_Date']; ?></td>
                    <!-- <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row16['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row16['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row16['Name']; ?>">
         
                                <input type="hidden" name="edit_company" value="<?php echo $row16['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row16['IMEI1']; ?>">
                            
                                <input type="hidden" name="edit_specs" value="<?php echo $row16['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row16['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row16['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row16['Purchased_Date']; ?>">
  
                                <input type="hidden" name="edit_category" value="<?php echo $row16['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row16['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                  </tr>
              <?php }}   } }
          // }

           // if($search === 'static_category'){ 

                //$Search_Item = "%".$Search_Item."%";
          $query17 = "SELECT * FROM product1 WHERE IMEI2 LIKE '".$Search_Item."' ";
          $query_run17 = mysqli_query($connection, $query17 );
          if(mysqli_num_rows($query_run17 ) > 0){
            while($row17  = mysqli_fetch_assoc($query_run17)){
                if($row17['Category'] === $Category AND $row17['Status'] === 'SOLD'){
                    $y=$row17['Product1_ID'];
                     if(!isset($GLOBALS[$y]) ){
                      $GLOBALS[$y]=$y;
                    ?>
                    <tr>
                  <!--     <td><?php  //echo $row17['Product1_ID']; ?></td> -->

                      <td><?php  echo $row17['Name']; ?></td>

                      <td><?php  echo $row17['Company']; ?></td>
                      <td><?php  echo $row17['Specification']; ?></td>
                      <td><?php  echo $row17['IMEI1']; ?></td>
                      <td><?php  echo $row17['IMEI2']; ?></td>

                     
                      <td><?php  echo $row17['Buying_Price']; ?></td>
                      <td><?php  echo $row17['Selling_Price']; ?></td>
                      <td><?php  echo $row17['Purchased_from']; ?></td>
                      <td><?php  echo $row17['Purchased_Date']; ?></td>
                   <!--  <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row17['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row17['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row17['Name']; ?>">
        
                                <input type="hidden" name="edit_company" value="<?php echo $row17['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row17['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row17['IMEI2']; ?>">
                              
                                <input type="hidden" name="edit_specs" value="<?php echo $row17['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row17['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row17['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row17['Purchased_Date']; ?>">
 
                                <input type="hidden" name="edit_category" value="<?php echo $row17['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row17['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                  </tr>
              <?php }}   } }
          // }


                //$Search_Item = "%".$Search_Item."%";
              $query19 = "SELECT * FROM product1 WHERE Purchased_Date LIKE '".$Search_Item."' ";
              $query_run19 = mysqli_query($connection, $query19);
              if(mysqli_num_rows($query_run19) > 0){
                while($row19 = mysqli_fetch_assoc($query_run19)){
                    if($row19['Category'] === $Category AND $row19['Status'] === 'SOLD'){
                        $z = $row19['Product1_ID'];
                          if(!isset($GLOBALS[$z]) ){
                            $GLOBALS[$z] = $z
                        ?>
                        <tr>
                          <!-- <td><?php  //echo $row19['Product1_ID']; ?></td> -->

                          <td><?php  echo $row19['Name']; ?></td>
           
                            <td><?php  echo $row19['Company']; ?></td>
                            
                               <td><?php  echo $row19['Specification']; ?></td>
            
                            <td><?php  echo $row19['IMEI1']; ?></td>
                            <td><?php  echo $row19['IMEI2']; ?></td>
                 
                        
                        <td><?php  echo $row19['Buying_Price']; ?></td>
                        <td><?php  echo $row19['Selling_Price']; ?></td>
                        <td><?php  echo $row19['Purchased_from']; ?></td>
                        <td><?php  echo $row19['Purchased_Date']; ?></td>
                       
                   <!--   <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php //echo $row19['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td> -->
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row19['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row19['Name']; ?>">
       
                                <input type="hidden" name="edit_company" value="<?php echo $row19['Company']; ?>">
                               
                                <input type="hidden" name="edit_imei1" value="<?php echo $row19['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row19['IMEI2']; ?>">
                             
                                <input type="hidden" name="edit_specs" value="<?php echo $row19['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row19['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row19['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row19['Purchased_Date']; ?>">
 
                                <input type="hidden" name="edit_category" value="<?php echo $row19['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row19['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>





                    </tr>


                <?php }} }       }    

}
                ?>
            </tbody>
        </table>

    </div>
</div>
</div>
</div>

<?php 

                                include('includes/scripts.php'); 
                                include('includes/footer.php'); 
                            ?>