<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 

$cat_query = "SELECT * FROM product_category";
$cat_query_run = mysqli_query($connection, $cat_query);

if(mysqli_num_rows($cat_query_run) > 0){
    while($cat_row = mysqli_fetch_assoc($cat_query_run)){
        $cat = $cat_row['Category'] ;
        if($cat != 'Mobile' AND $cat != 'Ipads'){
  
        $del_query = "DELETE FROM product1 WHERE Quantity=0 AND Category='$cat'";
        $del_query_run = mysqli_query($connection, $del_query);
    }
}}

?>


<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <form action="Add.php" method="post">
                <h6 class="n-0 font-weight-bold text-primary">

                	<center><button  type="button" name="#" class="btn btn-primary" data-toggle="modal" disabled>
                       PRODUCTS LISTS
                   </button></center>

               </form>

           </h6> </div>
       </div>
   </div>

    <?php  
                    if(isset($_SESSION['success']) && $_SESSION['success'] != '')
                    {
    echo '<h2 class="bg-primary" style="color:green; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:green; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>
  
   <div class="container-fluid">

      <div class="card shadow mb-4">
   
        <div class="card-header py-3">

            <form action="index.php" method="post">
       
 


      
                      <div class="dropdown">
           
            <select name="category" id="" class="dropbtn">
       <?php      $query3 = "SELECT * FROM product_category";
    $query_run3 = mysqli_query($connection, $query3);

     if(mysqli_num_rows($query_run3) > 0){
                while($row3 = mysqli_fetch_assoc($query_run3)){
                  ?>
              <option value="<?php echo $row3['Category'] ?>"><?php echo $row3['Category'] ?></option>
             <?php }}

            
              ?>
            </select>
             <input style="margin-left: 0rem; margin-top: 0px;" type="submit" value="SHOW" class="btn btn-primary myButton">
          </div>
        
               </form>

            </div>
       
       </div>
   </div>



 <?php

 if(isset($_POST["category"])){
    $_SESSION['category'] = $_POST["category"];
}

 if(isset($_SESSION['category'])){
    $query = "SELECT * FROM product_category";
    $query_run = mysqli_query($connection, $query);

     if(mysqli_num_rows($query_run) > 0){
                while($row = mysqli_fetch_assoc($query_run)){

                if($row['Category'] === $_SESSION['category']){ 
    ?>


   <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> <?php echo $row['Category'];?>


            </h6> </div>
            <div class="card-body">
       
             

  <div class="table-responsive">

    <?php
    $Category = $row['Category'];
    $query2 = "SELECT * FROM product1";
    $query_run2 = mysqli_query($connection, $query2);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <!-- <th> ID </th> -->
                <th>Name </th>
<?php if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                <th>Company </th>
    <?php } ?>
                  <th>Specification </th>
  <?php if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                <th>IMEI1 </th>
                <th>IMEI2 </th>
<?php } ?>
                
                <th style="width: 140px">Buying Price </th>
                <th style="width: 120px">Selling Price </th>
                <th style="width: 120px" >Purchased from </th>
                <th style="width: 120px">Purchased Date </th>
                <?php //if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                <!-- <th style="width: 120px">Status </th> -->
                <?php //} ?>
                <?php 
if($row['Category'] != 'Mobile' ){ 
    if($row['Category'] != 'Ipads' ){ 
    ?>
                <th>Quantity</th>
    <?php }} ?>
                <th>SELL</th>
                <th>EDIT</th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run2) > 0)        
            {
                while($row2 = mysqli_fetch_assoc($query_run2))
                {
                    if($row['Category'] === $row2['Category']){
                        if($row2['Status'] === 'AVAILABLE' ){ 

                    ?>
                    <tr>
                      <!--   <td><?php  //echo $row2['Product1_ID']; ?></td> -->
                       
                        <td><?php  echo $row2['Name']; ?></td>
<?php if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                        <td><?php  echo $row2['Company']; ?></td>
                    <?php } ?>
                      <td><?php  echo $row2['Specification']; ?></td>
 <?php if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                        <td><?php  echo $row2['IMEI1']; ?></td>
                        <td><?php  echo $row2['IMEI2']; ?></td>
 <?php } ?>
                      
                        <td ><?php  echo $row2['Buying_Price']; ?></td>
                        <td><?php  echo $row2['Selling_Price']; ?></td>
                        <td><?php  echo $row2['Purchased_from']; ?></td>
                        <td><?php  echo $row2['Purchased_Date']; ?></td>
                        <?php //if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                       <!--  <td><?php  //echo $row2['Status']; ?></td> -->
                         <?php //} ?>
<?php 
if($row['Category'] != 'Mobile' ){ 
    if($row['Category'] != 'Ipads' ){ 
    ?>
                        <td><?php  echo $row2['Quantity']; ?></td>
 <?php }} ?>
                         <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="cart_btn" class="btn btn-primary add_product_btn">Add To Cart</button>
                            </form>
                        </td>
                        <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row2['Name']; ?>">
                                <?php if($row['Category'] === 'Mobile'  OR $row['Category'] === 'Ipads' ){ ?>
                                <input type="hidden" name="edit_company" value="<?php echo $row2['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row2['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row2['IMEI2']; ?>">
                                 <?php } ?>
                                <input type="hidden" name="edit_specs" value="<?php echo $row2['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row2['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row2['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row2['Purchased_Date']; ?>">
                                <?php 
if($row['Category'] != 'Mobile' ){ 
    if($row['Category'] != 'Ipads' ){ 
    ?>
                                <input type="hidden" name="edit_quantity" value="<?php echo $row2['Quantity']; ?>">
<?php }} ?>
                                <input type="hidden" name="edit_category" value="<?php echo $row['Category']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                  }
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>

</div>
<?php 
}}}}

 ?>

<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>