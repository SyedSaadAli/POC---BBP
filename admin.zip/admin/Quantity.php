<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 


$id = $_POST['checkout_id'];
$product_id = $_POST['product_id'];
?>





	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Product Quantity</h6>

		</div>
		<div class="card-body">


			<form action="code1.php" method="POST" >


		<div class="form-group">
					<label>Quantity</label>
					<input type="number" name="Quantity"  value="" class="form-control" placeholder="Enter Quantity">
					

		<br></div>	
  <input type="hidden" name="Edit_Q_Id" value="<?php echo $id; ?>">
  <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
		
<center  style="display: flex; flex-direction: row; align-items: center; justify-content: center; " class="cntr_btns">

				<a  style="margin-bottom: 10px  ;" href="PreCheckout.php" class="btn btn-danger"> CANCEL </a>
				<div style="margin:0 1rem; ">&nbsp;</div>
				<button type="submit" name="edit_q_btn" class="btn btn-primary"> Edit </button>
</center>
			</form>

			

		<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>