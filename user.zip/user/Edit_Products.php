<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




<?php 

if(isset($_POST['edit_btn'])){

	$product_edit_id = $_POST['edit_id'];
	$Category = $_POST['edit_category'];
	$Heading = $Category;

	?>
	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">EDIT <?php echo $Heading; ?> </h6>

		</div>
		<div class="card-body">


			<form action="code1.php" method="POST" >




				
				<div class="form-group">
					<label>Name</label>
					<input type="text" name="Name"  value="<?php echo $_POST['edit_name']; ?>" class="form-control" placeholder="Enter Product Name">

				</div>
				<?php if($Category === 'Mobile'  OR $Category === 'Ipads' ){ ?>
				<div class="form-group">
					<label>Company</label>
					<input type="text" name="Company"  value="<?php echo $_POST['edit_company']; ?>" class="form-control" placeholder="Enter Company Name">
				</div>
				 <?php } ?>
				<div class="form-group">
					<label>Specification</label>
					
					 <textarea   class="form-control"  id="Specification" name="Specification"  onfocus='this.select()' >
					 	<?php echo htmlspecialchars($_POST['edit_specs']) ; ?></textarea>
					 
				</div>
				<?php if($Category === 'Mobile'  OR $Category === 'Ipads' ){ ?>
				<div class="form-group">
					<label>IMEI1</label>
					<input type="number" name="IMEI1"  value="<?php echo $_POST['edit_imei1']; ?>" class="form-control" placeholder="Enter IMEI1" required>
				</div>
				<div class="form-group">
					<label>IMEI2</label>
					<input type="number" name="IMEI2"  value="<?php echo $_POST['edit_imei2']; ?>" class="form-control" placeholder="Enter IMEI2">
				</div>
				 <?php } ?>
				<!-- <div width="500px" class="form-group" >
					<label>Specification</label>
					<input width="100" type="text" name="Specification"  value="<?php //echo $_POST['edit_specs']; ?>" class="form-control" placeholder="Enter Product Specification">
				</div> 
			 value="<?php //echo $_POST['edit_specs']; ?>"-->
				
				<div class="form-group">
					<label>Buying Price</label>
					<input type="number" name="Buying_price"  value="<?php echo $_POST['edit_buying']; ?>" class="form-control" placeholder="Enter Buying Price In AED">
				</div>
				<div class="form-group">
					<label>Selling Price</label>
					<input type="number" name="Selling_price"  value="<?php echo $_POST['edit_buying']; ?>" class="form-control" placeholder="Enter Selling Price In AED" required>
				</div>
				<div class="form-group">
					<label>Purchased from</label>
					<input type="text" name="purchased_from"  value="<?php echo $_POST['edit_purchased_from']; ?>" class="form-control" placeholder="Enter Purchased Venue">
				</div>
				<div class="form-group">
					<label>Purchased Date</label>
					<input type="Date" name="purchased_date"  value="<?php echo $_POST['edit_purchased_date']; ?>" class="form-control" placeholder="Enter Purchased Date">
				</div>
<?php 
if($Category != 'Mobile' ){ 
    if($Category != 'Ipads' ){ 
    ?>
				<div class="form-group">
					<label>Quantity</label>
					<input type="number" name="Quantity"  value="<?php echo $_POST['edit_quantity']; ?>" class="form-control " placeholder="Enter Quantity">
				</div>
	<?php }} ?>
	          <div class="form-group">
					<label>Status</label>
					 <select name="status" id="" class="form-control">
					 	 <option value="AVAILABLE">AVAILABLE</option>
					 	 <option value="SOLD">SOLD</option>
					 	 <option value="COMPLAIN">COMPLAIN</option>
					 	 </select>
				</div>
				<input type="number" name="product_edit_id"  value="<?php echo $product_edit_id; ?>" class="form-control " hidden>
				<input type="text" name="Category"  value="<?php echo $Category; ?>" class="form-control " hidden>

				

				<br></br>
				

				<center  style="display: flex; flex-direction: row; align-items: center; justify-content: center; " class="cntr_btns">
					<a style="margin-bottom: 10px  ;" href="index.php" class="btn btn-danger"> CANCEL </a>
					<div style="margin:0 1rem; ">&nbsp;</div>
					
					<button type="submit" name="products_edit_btn" class="btn btn-primary"> Edit </button>
				</center>
			</form>

			<?php 

		}

		?>





			</div>
		</div>
	</div>

	<!-- /.container-fluid -->

	<?php 
	include('includes/scripts.php'); 
	include('includes/footer.php'); 
?>