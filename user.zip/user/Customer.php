<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>
					<button  type="submit" name="add_customer" class="btn btn-primary">
						Invoice Records
					</button>
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"> All Customer Invoice Records


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:green; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:green; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM customer";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				<th> ID </th>
  				<th>Name </th>
  				<th>Mobile No</th>
  				<th>Selling Date</th>
  				<th>Invoice</th>
  				<th>Delete</th>
  			</tr>
  		</thead>
  		<tbody>
  			<?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					?>
  					<tr>
  					      <td><?php  echo $row['Customer_ID'] + 1000 ; ?></td> 
  						<td><?php  echo $row['Name'];?></td>
  						<td><?php  echo $row['Mobile_No'];?></td>
  						<td><?php  echo $row['Selling_Date'];?></td>
  						

  						<td style="padding: 0; margin: 0;">
  							<form action="InvoiceCopy.php" method="post">
  								<input type="hidden" name="Customer_id" value="<?php echo $row['Customer_ID']; ?>">
                                                <input type="hidden" name="Mobile_No" value="<?php echo $row['Mobile_No']; ?>">
  								<input type="hidden" name="Selling" value="<?php echo $row['Selling_Date']; ?>">
  								<input type="hidden" name="Name" value="<?php echo $row['Name']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="Customer_Invoice_copy_btn" class="btn btn-primary"> Invoice </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code1.php" method="post">
  								<input type="hidden" name="Customer_id" value="<?php echo $row['Customer_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this INVOICE  ?')" name="delete_invoice_btn" class="btn btn-danger"> Delete Invoice </button>
  							</form>
  						</td>
  					</tr>
  					<?php
  				} 
  			}
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>