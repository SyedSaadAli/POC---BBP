<?php 
include('security.php');



if(isset($_POST['add_c_btn']))
{

    $add_category = $_POST['add_category'];

    $query = "INSERT INTO product_category (Category) VALUES 
    ('$add_category')";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['status'] = "New Category is Added";
        $_SESSION['status_code'] = "success";
        header('Location: Add_Category.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Category is NOT Added";
        $_SESSION['status_code'] = "error";
        header('Location: Add_Category.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['C_delete_btn']))
{
    $id = $_POST['C_delete_id'];
    $Category = $_POST['Category'];

    // echo $id;
    // echo $Category;
    // exit();


    $query2 = "SELECT * FROM product1";
    $query_run2 = mysqli_query($connection, $query2);
    if(mysqli_num_rows($query_run2) > 0)        
    {
        while($row2 = mysqli_fetch_assoc($query_run2))
        {
            if($Category === $row2['Category'])
            {
                $id2 = $row2['Product1_ID'];
                $query3 = "DELETE FROM product1 WHERE product1_ID='$id2' ";
                $query_run3 = mysqli_query($connection, $query3);
            }
        }
    }

    $query = "DELETE FROM product_category WHERE Product_Category_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your selected product category is Deleted !";
        $_SESSION['status_code'] = "success";
        header('Location: Add_Category.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your selected product category is NOT DELETED !";       
        $_SESSION['status_code'] = "error";
        header('Location: Add_Category.php'); 
    }    
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add1_btn']))
{

   $product_category_id = $_POST['product_category_id'];
   $Category = $_POST['Category'];

   $Name = $_POST['Name'];
   $Company=$_POST['Company'];
    $Specification = $_POST['Specification'];
   $IMEI1=$_POST['IMEI1'];
   $IMEI2=$_POST['IMEI2'];
  
   $Buying_price = $_POST['Buying_price'];
   $Selling_price = $_POST['Selling_price'];
   $purchased_from = $_POST['purchased_from'];
   $purchased_date = $_POST['purchased_date'];
   


   $query = "INSERT INTO product1 (Category_ID,Name,Company,Specification,IMEI1,IMEI2,Buying_Price,Selling_Price,Purchased_from,Purchased_Date,Category,Status) VALUES 
   ('$product_category_id','$Name','$Company','$Specification','$IMEI1','$IMEI2','$Buying_price','$Selling_price','$purchased_from','$purchased_date','$Category','AVAILABLE')";
   $query_run = mysqli_query($connection, $query);


   if($query_run)
   {
    $_SESSION['status'] = "New Product is Added";
    $_SESSION['status_code'] = "success";
    header('Location: Add_Category.php'); 
}
else
{
    $_SESSION['status'] = "Your Product is NOT Added";
    $_SESSION['status_code'] = "error";
    header('Location: Add_Category.php');  
}
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add2_btn']))
{

    $product_category_id = $_POST['product_category_id'];
    $Category = $_POST['Category'];

    $Name = $_POST['Name'];
    $Specification = $_POST['Specification'];
    $Buying_price = $_POST['Buying_price'];
    $Selling_price = $_POST['Selling_price'];
    $purchased_from = $_POST['purchased_from'];
    $purchased_date = $_POST['purchased_date'];
    $Quantity = $_POST['Quantity'];



    $query = "INSERT INTO product1 (Category_ID,Name,Specification,Buying_Price,Selling_Price,Purchased_from,Purchased_Date,Quantity,Category,Status) VALUES 
    ('$product_category_id','$Name','$Specification','$Buying_price','$Selling_price','$purchased_from','$purchased_date','$Quantity','$Category','AVAILABLE')";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['status'] = "New Product is Added";
        $_SESSION['status_code'] = "success";
        header('Location: Add_Category.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Product is NOT Added";
        $_SESSION['status_code'] = "error";
        header('Location: Add_Category.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['p_delete_btn']))
{
    $id = $_POST['p_delete_id'];

    $query = "DELETE FROM product1 WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);


    header('Location: index.php'); 

}



if(isset($_POST['prd_delete_btn']))
{
    $id = $_POST['p_delete_id'];

    $query = "DELETE FROM product1 WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);


    header('Location: sold.php'); 

}

if(isset($_POST['prdd_delete_btn']))
{
    $id = $_POST['p_delete_id'];

    $query = "DELETE FROM product1 WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);


    header('Location: complain.php'); 

}

// ----------------------------------------------------------------------------------------------------------




// if(isset($_POST['add_customer_btn']))
// {

//     $Name = $_POST['Name'];
//     $Mobile_No = $_POST['Mobile_No'];
//     $Address = $_POST['Address'];
//     $Selling_Date = $_POST['Selling_Date'];



//     $query = "INSERT INTO customer (Name,Mobile_No,Address,Selling_Date) VALUES 
//     ('$Name','$Mobile_No','$Address','$Selling_Date')";
//     $query_run = mysqli_query($connection, $query);


//     if($query_run)
//     {
//         $_SESSION['status'] = "New Customer is Added";
//         $_SESSION['status_code'] = "success";
//         header('Location: Customer.php'); 
//     }
//     else
//     {
//         $_SESSION['status'] = "Customer is NOT Added";
//         $_SESSION['status_code'] = "error";
//         header('Location: Customer.php');  
//     }
// }




// ----------------------------------------------------------------------------------------------------------





if(isset($_POST['delete_invoice_btn']))
{
    $id = $_POST['Customer_id'];


    $query = "DELETE FROM customer WHERE Customer_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    $query2 = "DELETE FROM invoice WHERE Customer_ID='$id' ";
    $query_run2 = mysqli_query($connection, $query2);

    $query3 = "DELETE FROM product WHERE Invoice_ID='$id' ";
    $query_run3 = mysqli_query($connection, $query3);

    if($query_run)
    {
        $_SESSION['status'] = "Your Selected Invoice Is DELETED !";
        $_SESSION['status_code'] = "success";
        header('Location: Customer.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Selected Invoice Is NOT DELETED !";
        $_SESSION['status_code'] = "error";
        header('Location: Customer.php');  
    }
}




// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['cart_btn'])){

    $id = $_POST['cart_id'];

    $query = "SELECT * FROM product1 WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($query_run);

    $Name = $row['Name'];
    $Selling_Price = $row['Selling_Price'];
    $Category = $row['Category'];


    $query = "INSERT INTO checkout (Name,Category,Selling_Price,Tax,Quantity,Product_ID) VALUES ('$Name','$Category','$Selling_Price','$Selling_Price',1,'$id')";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
    {   
        $_SESSION['status'] = "Your Product Is Added To Bill Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Product Is Not Added To Bill !";
        $_SESSION['status_code'] = "error";
        header('Location: index.php');  
    }
    


    

}



// ----------------------------------------------------------------------------------------------------------





if(isset($_POST['checkout_delete_btn']))
{
    $id = $_POST['checkout_delete_id'];

    $query = "DELETE FROM checkout WHERE CheckOut_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: PreCheckout.php'); 
    }
    else
    {
        header('Location: PreCheckout.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['edit_q_btn']))
{
    $id = $_POST['Edit_Q_Id'];
    $product_id = $_POST['product_id'];
    $Quantity = $_POST['Quantity'];


     $query = "SELECT Quantity FROM product1 WHERE Product1_ID='$product_id'";
     $query_run = mysqli_query($connection, $query);
     $row = mysqli_fetch_assoc($query_run);
    


if($row['Quantity'] >= $Quantity){

    $query2 = "UPDATE checkout SET Quantity='$Quantity' WHERE CheckOut_ID='$id' ";
    $query_run2 = mysqli_query($connection, $query2);
}
  
    if($query_run2)
    {
        // $_SESSION['status'] = "Your product is Updated Successfully !";
        // $_SESSION['status_code'] = "success";
        header('Location: PreCheckout.php'); 
    }
    else
    {
        $_SESSION['status'] = "Selected quantity is not in stock! We have ".$row['Quantity']." in stock now!";       
        $_SESSION['status_code'] = "error";
        header('Location: PreCheckout.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['edit_c1_btn']))
{
    $id = $_POST['product_category_id'];
    $edit_category = $_POST['edit_category'];

    $query = "UPDATE product_category SET Category='$edit_category' WHERE Product_Category_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: Add_Category.php'); 
    }
    else
    {
        header('Location: Add_Category.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['edit_c2_btn']))
{
  $id = $_POST['product_category_id'];
  $edit_category = $_POST['edit_category'];

  $query = "UPDATE product_category SET Category='$edit_category' WHERE Product_Category_ID='$id' ";
  $query_run = mysqli_query($connection, $query);

  if($query_run)
  {
    header('Location: Add_Category.php'); 
}
else
{
    header('Location: Add_Category.php');  
}
}


// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['products_edit_btn']))
{
    $id = $_POST['product_edit_id'];
    $Category = $_POST['Category'];

    $Name = $_POST['Name'];
    if($Category === 'Mobile'  OR $Category === 'Ipads' ){ 
        $Company = $_POST['Company'];
     
        $IMEI1 = $_POST['IMEI1'];
        $IMEI2 = $_POST['IMEI2'];
    }
    $Specification = $_POST['Specification'];
    $Buying_price = $_POST['Buying_price'];
    $Selling_price = $_POST['Selling_price'];
    $purchased_from = $_POST['purchased_from'];
    $purchased_date = $_POST['purchased_date'];
    $status = $_POST['status'];
    if($Category != 'Mobile' ){ 
    if($Category != 'Ipads' ){ 
    $Quantity = $_POST['Quantity'];
         }} 



    if($Category === 'Mobile'  OR $Category === 'Ipads' ){ 
        $query = "UPDATE product1 SET Name='$Name',
        Company='$Company',
        Specification='$Specification',
        IMEI1='$IMEI1',
        IMEI2='$IMEI2',
        Buying_Price='$Buying_price',
        Selling_Price='$Selling_price',
        Purchased_from='$purchased_from',
        Purchased_Date='$purchased_date',
        Status='$status'  WHERE Product1_ID='$id' ";
        $query_run = mysqli_query($connection, $query);
    }
    else{
      $query = "UPDATE product1 SET Name='$Name',
      Specification='$Specification',
      Buying_Price='$Buying_price',
      Selling_Price='$Selling_price',
      Purchased_from='$purchased_from',
      Purchased_Date='$purchased_date',
      Quantity='$Quantity',
      Status='$status'  WHERE Product1_ID='$id' ";
      $query_run = mysqli_query($connection, $query);
      $query_run = mysqli_query($connection, $query);
  }

if($status === 'SOLD'){
  if($query_run)
  {
    $_SESSION['status'] = "Your product is Updated Successfully !";
    $_SESSION['status_code'] = "success";
    header('Location: sold.php'); 
}
else
{
    $_SESSION['status'] = "Your product is Not Updated !";       
    $_SESSION['status_code'] = "error";
    header('Location: sold.php'); 
}    
}

if($status === 'COMPLAIN'){
  if($query_run)
  {
    $_SESSION['status'] = "Your product is Updated Successfully !";
    $_SESSION['status_code'] = "success";
    header('Location: complain.php'); 
}
else
{
    $_SESSION['status'] = "Your product is Not Updated !";       
    $_SESSION['status_code'] = "error";
    header('Location: complain.php'); 
}    
}
if($status === 'AVAILABLE'){
  if($query_run)
  {
    $_SESSION['status'] = "Your product is Updated Successfully !";
    $_SESSION['status_code'] = "success";
    header('Location: index.php'); 
}
else
{
    $_SESSION['status'] = "Your product is Not Updated !";       
    $_SESSION['status_code'] = "error";
    header('Location: index.php'); 
}
}


}



// ----------------------------------------------------------------------------------------------------------

if(isset($_POST['tax']))
{ 

 $query = "SELECT * FROM checkout ";
 $query_run = mysqli_query($connection, $query);



 if(mysqli_num_rows($query_run) > 0){
    while($row = mysqli_fetch_assoc($query_run)){
        $CheckOut_ID = $row['CheckOut_ID'];
        $Selling_Price = $row['Selling_Price'];
        $Tax = $Selling_Price * 1.05 ; 

     
      
        $query2 = "UPDATE checkout SET Tax='$Tax' WHERE CheckOut_ID='$CheckOut_ID'";
        $query_run2 = mysqli_query($connection, $query2);

    }}   

    if($query_run)
    {
        header('Location: PreCheckout.php'); 
    }
    else
    {
        header('Location: PreCheckout.php');  
    }
    


}


// ----------------------------------------------------------------------------------------------------------

if(isset($_POST['rem_tax']))
{ 

 $query = "SELECT * FROM checkout ";
 $query_run = mysqli_query($connection, $query);



 if(mysqli_num_rows($query_run) > 0){
    while($row = mysqli_fetch_assoc($query_run)){
        $CheckOut_ID = $row['CheckOut_ID'];
        $Selling_Price = $row['Selling_Price'];
        $Tax = $row['Tax'];
        if($Tax > $Selling_Price){
        $T = $Tax - $Selling_Price ; 
        $Tax = $Tax - $T ;

     
      
        $query2 = "UPDATE checkout SET Tax='$Tax' WHERE CheckOut_ID='$CheckOut_ID'";
        $query_run2 = mysqli_query($connection, $query2);
}
    }}   

    if($query_run)
    {
        header('Location: PreCheckout.php'); 
    }
    else
    {
        header('Location: PreCheckout.php');  
    }
    


}


// ----------------------------------------------------------------------------------------------------------

if(isset($_POST['available_btn']))
{
    $id = $_POST['prd_id'];
    

    $query = "UPDATE product1 SET Status='AVAILABLE' WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: sold.php'); 
    }
    else
    {
        header('Location: sold.php');  
    }
}

// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['complain_btn']))
{
    $id = $_POST['prd_id'];
    

    $query = "UPDATE product1 SET Status='COMPLAIN' WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: sold.php'); 
    }
    else
    {
        header('Location: sold.php');  
    }
}

// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['available_btnn']))
{
    $id = $_POST['prd_id'];
    

    $query = "UPDATE product1 SET Status='AVAILABLE' WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: complain.php'); 
    }
    else
    {
        header('Location: complain.php');  
    }
}

// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['sold_btnn']))
{
    $id = $_POST['prd_id'];
    

    $query = "UPDATE product1 SET Status='SOLD' WHERE Product1_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        header('Location: complain.php'); 
    }
    else
    {
        header('Location: complain.php');  
    }
}
// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_customer']))
{


$query = "SELECT * FROM checkout";
$query_run = mysqli_query($connection, $query);
if(mysqli_num_rows($query_run) > 0)        
            {
              header('Location: Add_Customer.php');
            }else{
               header('Location: index.php');
            }


}

// ----------------------------------------------------------------------------------------------------------


?>