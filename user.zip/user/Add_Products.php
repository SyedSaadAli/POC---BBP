<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




<?php 

if(isset($_POST['add_p1_btn'])){

	$product_category_id = $_POST['product_category_id'];
	$Category = $_POST['Category'];
	$Heading = $Category ;

	?>
	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">ADD <?php echo $Heading; ?></h6>

		</div>
		<div class="card-body">


			<form action="code1.php" method="POST" >




				
				<div class="form-group">
					<label>Name</label>
					<input type="text" name="Name"  value="" class="form-control" placeholder="Enter Product Name">

				</div>
				<div class="form-group">
					<label>Company</label>
					<input type="text" name="Company"  value="" class="form-control" placeholder="Enter Company Name">
				</div>
				<div class="form-group">
					<label>Specification</label>
					<!-- <input type="text" name="Specification"  value="" class="form-control" placeholder="Enter Product Specification">
					 -->
					 <textarea class="form-control" placeholder="Enter Product Specification" id="Specification" name="Specification" rows="4"  ></textarea>
				</div>
				<div class="form-group">
					<label>IMEI1</label>
					<input type="number" data-bv-imei="true" name="IMEI1"  value="" class="form-control" placeholder="Enter IMEI1" required>
				</div>
				<div class="form-group">
					<label>IMEI2</label>
					<input type="number" data-bv-imei="true" name="IMEI2"  value="" class="form-control" placeholder="Enter IMEI2">
				</div>
				
				<div class="form-group">
					<label>Buying Price</label>
					<input type="number" name="Buying_price"  value="" class="form-control" placeholder="Enter Buying Price In AED">
				</div>
				<div class="form-group">
					<label>Selling Price</label>
					<input type="number" name="Selling_price"  value="" class="form-control" placeholder="Enter Selling Price In AED" required>
				</div>
				<div class="form-group">
					<label>Purchased from</label>
					<input type="text" name="purchased_from"  value="" class="form-control" placeholder="Enter Purchased Venue">
				</div>
				<div class="form-group">
					<label>Purchased Date</label>
					<input type="Date" name="purchased_date"  value="" class="form-control" placeholder="Enter Purchased Date">
				</div>

				
				<input type="number" name="product_category_id"  value="<?php echo $product_category_id; ?>" class="form-control " hidden>
				<input type="text" name="Category"  value="<?php echo $Category; ?>" class="form-control " hidden>

				

				<br></br>
				

				<center  style="display: flex; flex-direction: row; align-items: center; justify-content: center; " class="cntr_btns">
					<a style="margin-bottom: 10px  ;" href="Add_Category.php" class="btn btn-danger"> CANCEL </a>
					<div style="margin:0 1rem; ">&nbsp;</div>
					
					<button type="submit" name="add1_btn" class="btn btn-primary"> Add </button>
				</center>
			</form>

			<?php 

		}

		?>




		<?php 

		if(isset($_POST['add_p2_btn'])){

			$product_category_id = $_POST['product_category_id'];
			$Category = $_POST['Category'];
			$Heading = $Category ;


			?>
			<!-- Datatables Example -->
			<div class="card shadow mb-4">
				<div class="card-header py-3">
					<h6 class="n-0 font-weight-bold text-primary">ADD <?php echo $Heading; ?></h6>

				</div>
				<div class="card-body">


					<form action="code1.php" method="POST" >





						<div class="form-group">
							<label>Name</label>
							<input type="text" name="Name"  value="" class="form-control" placeholder="Enter Product Name">

						</div>

						<div class="form-group">
					<label>Specification</label>
					<!-- <input type="text" name="Specification"  value="" class="form-control" placeholder="Enter Product Specification">
					 -->
					 <textarea class="form-control" placeholder="Enter Product Specification" id="Specification" name="Specification" rows="4"  ></textarea>
				</div>
						<div class="form-group">
							<label>Buying Price</label>
							<input type="number" name="Buying_price"  value="" class="form-control" placeholder="Enter Buying Price">
						</div>
						<div class="form-group">
							<label>Selling Price</label>
							<input type="number" name="Selling_price"  value="" class="form-control" placeholder="Enter Selling Price" required>
						</div>
						<div class="form-group">
							<label>Purchased from</label>
							<input type="text" name="purchased_from"  value="" class="form-control" placeholder="Enter Purchased Venue">
						</div>
						<div class="form-group">
							<label>Purchased Date</label>
							<input type="Date" name="purchased_date"  value="" class="form-control" placeholder="Enter Purchased Date">
						</div>

						<div class="form-group">
							<label>Quantity</label>
							<input type="number" name="Quantity"  value="" class="form-control " placeholder="Enter Quantity">
						</div>
						<input type="number" name="product_category_id"  value="<?php echo $product_category_id; ?>" class="form-control " hidden>
						<input type="text" name="Category"  value="<?php echo $Category; ?>" class="form-control " hidden>
						<br></br>


							<center  style="display: flex; flex-direction: row; align-items: center; justify-content: center; " class="cntr_btns">
							<a style="margin-bottom: 10px  ;" href="Add_Category.php" class="btn btn-danger"> CANCEL </a>
							<div style="margin:0 1rem; ">&nbsp;</div>
							<button type="submit" name="add2_btn" class="btn btn-primary"> Add </button>
						</center>
					</form>

					<?php 

				}

				?>
			</div>
		</div>
	</div>

	<!-- /.container-fluid -->

	<?php 
	include('includes/scripts.php'); 
	include('includes/footer.php'); 
?>