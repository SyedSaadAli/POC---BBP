<?php
if($_SESSION['Admin_Username'] === 'User')
{
	
} else{
	header('location:../login.php');
}
?>