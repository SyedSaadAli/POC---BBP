<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 

?>

<style> 
    .misearchform{
        padding: 20px 30px;
        width: 600px;
    }
    .mibtn{
        padding: 5px 20px;
        background-color:#054181;
        color: white;
    }
    .micat{
        padding: 5px 20px;
     
    }
    .mibtn:hover{
        transition: 0.3s;
        background-color: #053181;
    }
    .misearch{
        padding: 5px 20px;
        border:2px solid #054181;
    }
    .micat option{
        background-color: none !important;
        
    }
    </style>

    
<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <form action="Complain.php" method="post">
                <h6 class="n-0 font-weight-bold text-primary">

                	<center>
                        <button style="margin:5px;" type="submit" name="Category" value="Mobile" class="btn btn-primary" data-toggle="modal" >
                       MOBILE
                   </button>
                   <button style="margin:5px;" type="submit" name="Category" value="Ipads" class="btn btn-primary" data-toggle="modal" >
                       IPADS
                   </button>
               </center>

               </form>

           </h6> </div>
       </div>
   </div>

    <?php  
                    if(isset($_SESSION['success']) && $_SESSION['success'] != '')
                    {
    echo '<h2 class="bg-primary" style="color:green; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:green; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  
     if(isset($_POST["Category"])){
    $_SESSION['Category'] = $_POST["Category"];
}

   if(isset($_SESSION['Category'])){
    $Category = $_SESSION['Category'];

   


?>
   <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
          <!--Search Bar Code Start-->
       
    
 <form action="search3.php" method="POST" class="misearchform">
        <input type="text" name="search" placeholder="Enter to Search" class="misearch">
        <input type="submit" name="Search_btn" value="Search" class="mibtn">
        <select name="cat" id="cat" class="micat">
            <option value="Mobile">Mobile</option>
            <option value="Ipads">ipad</option>
        </select>
    </form>



        <!--Search Bar Code Ends-->
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> <?php echo $Category;?>


            </h6> </div>
            <div class="card-body">
       
            

  <div class="table-responsive">

    <?php
  
    $query2 = "SELECT * FROM product1";
    $query_run2 = mysqli_query($connection, $query2);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <!-- <th> ID </th> -->
                <th>Name </th>

                <th>Company </th>
               <th>Specification </th>
                <th>IMEI1 </th>
                <th>IMEI2 </th>
                
                <th style="width: 140px">Buying Price </th>
                <th style="width: 120px">Selling Price </th>
                <th style="width: 120px" >Purchased from </th>
                <th style="width: 120px">Purchased Date </th>
            
                <th style="width: 120px">Status </th>
                <th style="width: 120px">Available </th>
            
                <th style="width: 120px">Sold </th>
                 <th style="width: 120px">Edit </th>
                <th style="width: 120px">Delete </th>
             
               
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run2) > 0)        
            {
                while($row2 = mysqli_fetch_assoc($query_run2))
                {
                    if($row2['Category'] === $Category AND $row2['Status'] === 'COMPLAIN'){
                    ?>
                    <tr>
                      <!--   <td><?php  //echo $row2['Product1_ID']; ?></td> -->
                       
                        <td><?php  echo $row2['Name']; ?></td>

                        <td><?php  echo $row2['Company']; ?></td>
                        <td><?php  echo $row2['Specification']; ?></td>
                        <td><?php  echo $row2['IMEI1']; ?></td>
                        <td><?php  echo $row2['IMEI2']; ?></td>

                        
                        <td ><?php  echo $row2['Buying_Price']; ?></td>
                        <td><?php  echo $row2['Selling_Price']; ?></td>
                        <td><?php  echo $row2['Purchased_from']; ?></td>
                        <td><?php  echo $row2['Purchased_Date']; ?></td>
                       
                        <td><?php  echo $row2['Status']; ?></td>
                        <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="prd_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="available_btnn" class="btn btn-primary add_product_btn">Available</button>
                            </form>
                        </td>
                        
                         <td style="width: 140px !important ; ">
                            <form action="code1.php" method="post">
                                <input type="hidden" name="prd_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="sold_btnn" class="btn btn-primary add_product_btn">Sold</button>
                            </form>
                        </td>
                         <td style="width: 140px !important ; ">
                            <form action="Edit_Products.php" method="post">
                                <input type="hidden" name="edit_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <input type="hidden" name="edit_name" value="<?php echo $row2['Name']; ?>">
                               
                                <input type="hidden" name="edit_company" value="<?php echo $row2['Company']; ?>">
                                
                                <input type="hidden" name="edit_imei1" value="<?php echo $row2['IMEI1']; ?>">
                                <input type="hidden" name="edit_imei2" value="<?php echo $row2['IMEI2']; ?>">
                           
                                <input type="hidden" name="edit_specs" value="<?php echo $row2['Specification']; ?>">
                                <input type="hidden" name="edit_buying" value="<?php echo $row2['Buying_Price']; ?>">
                                <input type="hidden" name="edit_purchased_from" value="<?php echo $row2['Purchased_from']; ?>">
                                <input type="hidden" name="edit_purchased_date" value="<?php echo $row2['Purchased_Date']; ?>">

                                <input type="hidden" name="edit_category" value="<?php echo $row2['Category']; ?>">
                                <input type="hidden" name="edit_status" value="<?php echo $row2['Status']; ?>">
                                <button style=" margin-left: 1rem; margin-top: 2px; padding: 5px; width: 100px; " type="submit" name="edit_btn" class="btn btn-primary add_product_btn" onclick="javascript: return confirm('Are you sure you want to EDIT this product  ?')">Edit</button>
                            </form>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row2['Product1_ID']; ?>">
                                <button type="submit" name="prdd_delete_btn" class="btn btn-danger"  onclick="javascript: return confirm('Are you sure you want to DELETE this product  ?')"> DELETE</button>
                            </form>
                        </td>
                     

                    </tr>
                    <?php
                  }
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
<?php 

}
 ?>
</div>


<!-- /.container-fluid -->




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>