<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 


?>


<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="code1.php" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>
					<button  type="submit" name="add_customer" class="btn btn-primary">
						ADD CUSTOMER
					</button>
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Pre-Checkout</h6>

		</div>
		   <div class="card-body">

              <?php  
                    if(isset($_SESSION['success']) && $_SESSION['success'] != '')
                    {
    echo '<h2 class="bg-primary" style="color:green; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:green; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

    <?php
   
    $query = "SELECT * FROM checkout";
    $query_run = mysqli_query($connection, $query);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
              
                <th>Name </th>
                <th>Category </th>
                <th>Sell Price </th>
                <th>Quantity</th>
                <th>After Tax</th>
                <th>ADD QUANTITY</th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                { ?>
                    
                    <tr>
                   
                       
                        <td><?php  echo $row['Name']; ?></td>
                        <td><?php  echo $row['Category']; ?></td>
                        <td><?php  echo $row['Selling_Price']; ?></td>
                           <?php 
if($row['Category'] != 'Mobile' AND $row['Category'] != 'Ipads'){ 
   
    ?>
                        <td><?php  echo $row['Quantity']; ?></td>
        <?php }else{  ?>
            <td></td>
      <?php  }
    ?>
                        <td><?php  echo $row['Tax']; ?></td>
                         <td style="padding: 0; margin: 0;">
                             <?php 
if($row['Category'] != 'Mobile' AND $row['Category'] != 'Ipads'){ 
  
    ?>
                            <form action="Quantity.php" method="post">
                                <input type="hidden" name="checkout_id" value="<?php echo $row['CheckOut_ID']; ?>">
                                 <input type="hidden" name="product_id" value="<?php echo $row['Product_ID']; ?>">
                                <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="checkout_btn" class="btn btn-primary"> ADD</button>
                            </form>
                              <?php }else{  ?>
             <button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="checkout_btn" class="btn btn-primary"> FIXED</button>
      <?php  }
?>
                        </td>

                        <td>
                            <form action="code1.php" method="post">
                                <input type="hidden" name="checkout_delete_id" value="<?php echo $row['CheckOut_ID']; ?>">
                                <button type="submit" name="checkout_delete_btn" class="btn btn-danger"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                  }
                } 
            
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>

  


</div>

  <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

        <div  class="card-header py-3">
            <form action="code1.php" method="post">
                <h6 class="text-right" class="n-0 font-weight-bold text-primary">
              
                    <button  type="submit" name="tax" class="btn btn-primary">
                        ADD TAX
                    </button>
      

                </form>
                
            </h6>
            <br> 
              <form action="code1.php" method="post">
                <h6 class="text-right" class="n-0 font-weight-bold text-primary">
              
                    <button  type="submit" name="rem_tax" class="btn btn-primary">
                        REMOVE TAX
                    </button>
      

                </form>

            </h6> 
        </div>
        </div>
    </div>


</div>
		

		<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>